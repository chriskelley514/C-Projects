#include <iostream>
#include <cmath>    // Include the cmath library for the M_PI constant

// Circle class definition
class Circle {
private:
    double radius;  // Private member variable to hold the radius of the circle

public:
    // Constructor with default radius
    Circle(double r = 0.0) : radius(r) {}

    // Set the radius of the circle
    void setRadius(double r) {
        radius = r;
    }

    // Get the radius of the circle
    double getRadius() const {
        return radius;
    }

    // Calculate the area of the circle
    double calculateArea() const {
        return M_PI * radius * radius;
    }
};

// Node structure for linked list
struct Node {
    Circle data;  // Data in the node, which is a Circle object
    Node* next;   // Pointer to the next node in the list

    Node(Circle c) : data(c), next(nullptr) {}  // Constructor initializing the node with a Circle object and next to nullptr
};

// Class to manage the linked list
class LinkedList {
private:
    Node* head;  // Pointer to the first node of the list

public:
    // Constructor initializes the linked list as empty
    LinkedList() : head(nullptr) {}

    // Insert a new circle at the end of the list
    void insertCircle(Circle c) {
        Node* newNode = new Node(c);  // Create a new node with the circle
        if (head == nullptr) {
            head = newNode;  // If the list is empty, set head to the new node
        } else {
            Node* current = head;  // Start from the head of the list
            while (current->next != nullptr) {
                current = current->next;  // Traverse to the end of the list
            }
            current->next = newNode;  // Link the new node at the end of the list
        }
    }

    // Function to display all circles
    void displayAllElements() {
        Node* current = head;  // Start from the head
        int position = 1;  // Initialize position counter to start from 1
        while (current != nullptr) {
            std::cout << "Position: " << position << ", Radius: " << current->data.getRadius()
                      << ", Area: " << current->data.calculateArea() << std::endl;
            current = current->next;  // Move to the next node
            position++;  // Increment the position counter
        }
    }

    // Destructor to clean up memory
    ~LinkedList() {
        Node* current = head;  // Start from the head
        while (current != nullptr) {
            Node* temp = current;  // Store current node in temp
            current = current->next;  // Move to next node
            delete temp;  // Delete the temp node, freeing memory
        }
    }
};

// Main function to test the linked list with circles
int main() {
    LinkedList list;
    int numCircles;
    double radius;

    std::cout << "Enter the number of circles: ";  // Prompt user for the number of circles
    std::cin >> numCircles;  // Read the number of circles

    for (int i = 0; i < numCircles; ++i) {
        std::cout << "Enter the radius for circle " << (i + 1) << ": ";  // Ask for radius for each circle
        std::cin >> radius;  // Read the radius
        Circle c(radius);  // Create a new circle with the given radius
        list.insertCircle(c);  // Insert the circle into the list
    }

    list.displayAllElements();  // Display all circles in the list

    return 0;  // Exit the program
}
