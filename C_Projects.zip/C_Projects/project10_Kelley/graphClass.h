#include <iostream>
#include <vector>

class Graph {
private:
    std::vector<GraphNode*> nodes;

public:
    ~Graph() {
        for (auto node : nodes) {
            delete node;
        }
    }

    void createNodes(int n) {
        for (int i = 1; i <= n; ++i) {
            nodes.push_back(new GraphNode(i));
        }
    }

    void addConnections(const std::vector<std::vector<int>>& adjacencyMatrix) {
        for (int i = 0; i < adjacencyMatrix.size(); ++i) {
            for (int j = 0; j < adjacencyMatrix[i].size(); ++j) {
                if (adjacencyMatrix[i][j] == 1) {
                    nodes[i]->addConnection(nodes[j]);
                }
            }
        }
    }

    void buildGraph(int n, const std::vector<std::vector<int>>& adjacencyMatrix) {
        createNodes(n);
        addConnections(adjacencyMatrix);
    }

    void displayGraph() {
        for (auto node : nodes) {
            std::cout << "Node " << node->pointNum << " connects to: ";
            for (auto connectedNode : node->connectedNodes) {
                std::cout << connectedNode->pointNum << " ";
            }
            std::cout << std::endl;
        }
    }
};
