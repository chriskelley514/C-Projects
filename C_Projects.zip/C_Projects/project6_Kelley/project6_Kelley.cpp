#include <iostream>
#include <stack>
#include <vector>

// Class to represent a circle with a single attribute: radius.
class Circle {
private:
    double radius;  // Radius of the circle.

public:
    // Default constructor initializes radius to zero.
    Circle() : radius(0.0) {}

    // Setter method to set the radius of the circle.
    void setRadius(double r) {
        radius = r;
    }

    // Getter method to obtain the radius of the circle.
    double getRadius() const {
        return radius;
    }

    // Method to calculate and return the area of the circle.
    double calculateArea() const {
        return 3.14159 * radius * radius;
    }
};

// Function to display all circles stored in the stack.
void DisplayAllCircles(std::stack<Circle>& stack) {
    std::vector<Circle> temp;  // Temporary vector to store circle objects.

    // Transfer all elements from stack to the temporary vector.
    while (!stack.empty()) {
        temp.push_back(stack.top());
        stack.pop();
    }

    // Check if the temporary vector is empty, indicating an empty stack.
    if (temp.empty()) {
        std::cout << "The stack is empty.\n";
    } else {
        // Display all circles from temporary vector.
        for (int i = temp.size() - 1; i >= 0; --i) {
            std::cout << "Circle " << i + 1 << " - Radius: " << temp[i].getRadius()
                      << ", Area: " << temp[i].calculateArea() << std::endl;
        }

        // Restore the elements to the stack from the temporary vector.
        for (int i = temp.size() - 1; i >= 0; --i) {
            stack.push(temp[i]);
        }
    }
}

// Main function to drive the application.
int main() {
    std::stack<Circle> circleStack;  // Stack to hold Circle objects.
    int choice = 0;  // User choice for menu options.
    double radius;  // Radius input for a circle.

    do {
        std::cout << "1. Insert a Circle\n";
        std::cout << "2. Display All Circles\n";
        std::cout << "3. Remove All Circles\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:  // Option to insert a circle into the stack.
                std::cout << "Enter radius of the circle: ";
                std::cin >> radius;
                {
                    Circle c;
                    c.setRadius(radius);
                    circleStack.push(c);
                    std::cout << "Circle pushed to stack.\n";
                }
                break;
            case 2:  // Option to display all circles.
                DisplayAllCircles(circleStack);
                break;
            case 3:  // Option to remove all circles from the stack.
                while (!circleStack.empty()) {
                    circleStack.pop();
                }
                std::cout << "All circles removed from the stack.\n";
                break;
            case 4:  // Option to exit the program.
                std::cout << "Exiting application.\n";
                break;
            default:  // Handle invalid choices.
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 4);  // Continue until the user selects 'Exit'.

    return 0;  // End of the program.
}
