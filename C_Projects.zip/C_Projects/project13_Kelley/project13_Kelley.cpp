#include <iostream>
#include <vector>
#include <queue>
#include <memory>
#include <climits>
#include <algorithm>
// Class representing a node in the graph
class GraphNode {
public:
    int pointNum; // Node identifier
    int inDegree; // In degree of the node
    int topNum; // Topological number of the node
    int dist; // Distance for unweighted shortest path
    GraphNode* path; // Path for unweighted shortest path
    std::vector<std::shared_ptr<GraphNode>> connectedNodes; // List of nodes this node is connected to

    // Constructor to initialize the node with a given number
    explicit GraphNode(int num) : pointNum(num), inDegree(0), topNum(0), dist(INT_MAX), path(nullptr) {}

    // Method to add a connection to another node
    void addConnection(const std::shared_ptr<GraphNode>& node) {
        connectedNodes.push_back(node);
        node->inDegree++;
    }

    // Accessor and mutator for topNum
    [[nodiscard]] int getTopNum() const { return topNum; }
    void setTopNum(int num) { topNum = num; }

    // Accessor and mutator for dist
    [[nodiscard]] int getDist() const { return dist; }
    void setDist(int d) { dist = d; }

    // Accessor and mutator for path
    [[nodiscard]] GraphNode* getPath() const { return path; }
    void setPath(GraphNode* p) { path = p; }
};

// Class representing the graph
class Graph {
private:
    std::vector<std::shared_ptr<GraphNode>> nodes; // List of nodes in the graph

public:
    // Destructor to clean up the nodes
    ~Graph() = default;

    // Method to create nodes in a graph
    void createNodes(int n) {
        for (int i = 1; i <= n; ++i) {
            nodes.push_back(std::make_shared<GraphNode>(i));
        }
    }

    // Method to add connections between nodes based on the adjacency matrix
    void addConnections(const std::vector<std::vector<int>>& adjacencyMatrix) {
        for (int i = 0; i < adjacencyMatrix.size(); ++i) {
            for (int j = 0; j < adjacencyMatrix[i].size(); ++j) {
                if (adjacencyMatrix[i][j] == 1) {
                    nodes[i]->addConnection(nodes[j]);
                }
            }
        }
    }

    // Method to build the graph with the given number of nodes and adjacency matrix
    void buildGraph(int n, const std::vector<std::vector<int>>& adjacencyMatrix) {
        createNodes(n);
        addConnections(adjacencyMatrix);
    }

    // Unweighted shortest path method
    void unweighted(int startPoint) {
        std::queue<GraphNode*> q;
        // Initialize distances
        for (auto& node : nodes) {
            node->setDist(INT_MAX);
        }
        // Set start node distance to 0
        auto startNode = nodes[startPoint - 1];
        startNode->setDist(0);
        q.push(startNode.get());
        // BFS to find the shortest path
        while (!q.empty()) {
            GraphNode* v = q.front();
            q.pop();

            for (const auto& w : v->connectedNodes) {
                if (w->getDist() == INT_MAX) { // Node not yet visited
                    w->setDist(v->getDist() + 1);
                    w->setPath(v);
                    q.push(w.get());
                }
            }
        }
    }

    // Method to display the shortest path from start node to end node
    void displayShortestPath(int startPoint, int endPoint) {
        auto endNode = nodes[endPoint - 1];
        if (endNode->getDist() == INT_MAX) { // No path found
            std::cout << "No path from " << startPoint << " to " << endPoint << std::endl;
        } else {
            std::cout << "Shortest path from " << startPoint << " to " << endPoint << ": " << std::endl;
            std::vector<int> path;
            for (GraphNode* node = endNode.get(); node != nullptr; node = node->getPath()) {
                path.push_back(node->pointNum);
            }
            std::reverse(path.begin(), path.end()); // Reverse path to start from the beginning
            for (int num : path) {
                std::cout << num << " ";
            }
            std::cout << "\nDistance: " << endNode->getDist() << std::endl;
        }
    }
};

int main() {
    int n;
    std::cout << "Enter the number of nodes: ";
    std::cin >> n;
    // Read adjacency matrix
    std::vector<std::vector<int>> adjacencyMatrix(n, std::vector<int>(n));
    std::cout << "Enter the adjacency matrix with a space between connections(0 or 1):" << std::endl;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            std::cin >> adjacencyMatrix[i][j];
        }
    }
    // Build and compute the shortest paths in the graph
    Graph graph;
    graph.buildGraph(n, adjacencyMatrix);

    int startPoint, endPoint;
    std::cout << "Enter the starting point(1 index): ";
    std::cin >> startPoint;
    std::cout << "Enter the ending point(1 index): ";
    std::cin >> endPoint;

    graph.unweighted(startPoint);
    graph.displayShortestPath(startPoint, endPoint);

    return 0;
}
