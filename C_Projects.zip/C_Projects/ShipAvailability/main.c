#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MIN_SHIP_LINES 1
#define MAX_SHIP_LINES 100
#define MAX_SHIPS_PER_LINE 100
#define MIN_NAME_LENGTH 1
#define MAX_NAME_LENGTH 20

int main()
{
    int numLines = 0;
    char temp[1000];
    char split[1] = {' '};
    int numOfWeeksInput = 0;
    int weekNumber = 0;

    scanf("%d", &numLines);
    getchar();

    if (numLines > MAX_SHIP_LINES || numLines < MIN_SHIP_LINES)
    {
        return -1;
    }

    char shipNames[numLines][MAX_SHIPS_PER_LINE][MAX_NAME_LENGTH + 1];
    int *actualShips = calloc(numLines, sizeof(int)); // stores the actual number of ships in each row

    // takes input till the number of lines mentioned
    for (int i = 0; i < numLines; i++)
    {
        fgets(temp, 1000, stdin);      // capturing the string
        temp[strcspn(temp, "\n")] = 0; // removes new line character from the end of the string
        int shipCounter = 0;
        char *token = strtok(temp, split); // arsh sharma is my name
        strcpy(shipNames[i][shipCounter], token);
        shipCounter++;
        while (1)
        {
            token = strtok(NULL, split);
            if (token == NULL)
            {
                break;
            }
            strcpy(shipNames[i][shipCounter], token);
            shipCounter++;
        }
        actualShips[i] = shipCounter;
    }

    scanf("%d", &numOfWeeksInput);
    getchar();

    // fixing the rotated values in the ship names
    for (int i = 0; i < numOfWeeksInput; i++)
    {
        scanf("%d", &weekNumber);
        getchar();
        if (weekNumber < 1 || weekNumber > 100000)
        {
            return -1;
        }
        // replacing each row with updated rotation
        for (int lineIndex = 0; lineIndex < numLines; lineIndex++)
        {
            char tempShipNames[actualShips[lineIndex]][MAX_NAME_LENGTH + 1];

            // storing the names of the current row in temp array
            for (int currentIndex = 0; currentIndex < actualShips[lineIndex]; currentIndex++)
            {
                strcpy(tempShipNames[currentIndex], shipNames[lineIndex][currentIndex]);
            }

            // rotating the values in the array with one less week
            for (int rotateIndex = 0; rotateIndex < weekNumber - 1; rotateIndex++)
            {
                char tempName[21]; // first ship name in the array
                strcpy(tempName, tempShipNames[0]);
                // responsible for moving forward the values in the array
                for (int moveForwardIndex = 1; moveForwardIndex < actualShips[lineIndex]; moveForwardIndex++)
                {
                    strcpy(tempShipNames[moveForwardIndex - 1], tempShipNames[moveForwardIndex]);
                }

                // add the first name to the last position
                strcpy(tempShipNames[actualShips[lineIndex] - 1], tempName);
            }

            printf("%s ", tempShipNames[0]);
        }
        printf("\n");
    }

    return 0;
}
