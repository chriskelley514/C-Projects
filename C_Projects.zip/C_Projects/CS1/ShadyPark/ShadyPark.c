#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
//#include <stdbool.h>

#define N_MIN 2  //min number of sun-blocking towers 
#define N_MAX 500000 //max number of sun-blocking towers 
#define L_MIN 1 //min length of the park 
#define L_MAX 1000000000 //max length of the park 
#define P_MIN 1 //min percentage of park shaded 
#define P_MAX 100 //max percentage of park shaded 


double binarySearch_east(double location[], double height[], double high, double low, double shadedArea, double totalshadowLength, double towerShadow[], int sunBlockingTowers);

//float binarySearch_west(float, float, float, float, int); 

int main(){
    char userInput[100];
    char *token;
    int sunBlockingTowers = N_MIN;
    float parkLength = 0;
    float shadedPercentage = 0;
    double location[sunBlockingTowers];
    double height[100];
    int temp;
    //int *towers;
    float totalshadowLength = 0;
    double towerShadow[sunBlockingTowers];

    fgets(userInput, 100, stdin);
    

    // extracting values from string

    // sun blocking towers
    token = strtok(userInput, " ");
    temp = atoi(token);
    
    if(temp >= N_MIN && temp <= N_MAX){
        sunBlockingTowers = atoi(token); 
    }
    else{
        printf("Invalid number of sun blocking towers");
 	    fgets(userInput, 100, stdin);
    }

    // park length
    token = strtok(NULL, " ");
    temp = atoi(token);
    
    if(temp >= L_MIN && temp <= L_MAX){
        parkLength = atoi(token);
    }
    else{
        printf("Invalid park length");
        fgets(userInput, 100, stdin);
    }

    // shaded percentage
    token = strtok(NULL, " ");
    temp = atoi(token);
    
    if(temp >= P_MIN && temp <= P_MAX){
        shadedPercentage = atoi(token);
    }
    else{
        printf("Invalid shaded percentage");
        fgets(userInput, 100, stdin);
    }
    

    // extracting tower locations
    for (int i = 0; i < sunBlockingTowers; i++){
        char *token2;
        fgets(userInput, 100, stdin);
        token2 = strtok(userInput, " ");
        location[i] = atoi(token2);

        for (int j = 0; j < i; j++) {
            token2 = strtok(NULL, " ");
            height[j] = atoi(token2);

        }
    }
    
    // creating the 2D array to store the towers

    
    //EAST
    //float mid; 
    //float target; 
    
    //Binary Search for east 
    //binarySearch_east(90.0, 0.0, 45.0, eastAngle, shadedPercentage);

    // calculating the shaded area
    double shadedArea = (parkLength * shadedPercentage) / 100;

    // calculating the East angle
    double eastAngle;

    double totalHeightEast = 0;

    //for (float i = 0; i < sunBlockingTowers; i++){
        totalHeightEast += *height; //change
    //}

    binarySearch_east(location, height, 90, 0, shadedArea, totalshadowLength, towerShadow, sunBlockingTowers);

    eastAngle = atan(totalHeightEast / totalshadowLength);
    eastAngle = floor(eastAngle * 1000) / 1000;

    printf("East angle: %f", eastAngle);
    
    //for (int i = 0; i < sunBlockingTowers; i++){

        return 0;    
}


double binarySearch_east(double location[], double height[], double high, double low, double shadedArea, double totalshadowLength, double towerShadow[], int sunBlockingTowers){
	//high = 90;
	//low = 0;
    double mid = (low + high) / 2;
    double degreeToRadian = (90 - mid) * (M_PI / 180);

    for(int i = 0; i < sunBlockingTowers; i++){
        towerShadow[i] = degreeToRadian * height[i];
    }

	for(int i = 0; i < sunBlockingTowers; i++){
        totalshadowLength += towerShadow[i];
    }
	
	for (int i = 0; i < sunBlockingTowers; i++){
		if(&towerShadow[i] > location){
			totalshadowLength += towerShadow[i];
			continue; 
		}
		else{
			totalshadowLength += towerShadow[sunBlockingTowers];
		}
	}
	
	if (totalshadowLength == shadedArea){
		return totalshadowLength;
		}
			 
	else if (totalshadowLength > shadedArea){
		return binarySearch_east(location, height, high, mid, shadedArea, totalshadowLength, towerShadow, sunBlockingTowers);
		}

	else if (totalshadowLength < shadedArea){
        return binarySearch_east(location, height, mid, low, shadedArea, totalshadowLength, towerShadow, sunBlockingTowers);
		}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
