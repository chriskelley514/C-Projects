#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define ROWS 4
#define COLS 4
#define LETTERS 26
#define DICE 16
#define SIDES 6
#define TRUE 1
#define FALSE 0
#define SPACE ' '
#define NAME 20
#define WORDS 100
#define LENGTH 17
#define MAX 10
#define TIME 180

struct Player {
    char name[NAME];
    char words[WORDS][LENGTH];
    int score;
    int count;
};


// declaration of functions
void welcomeScreen(void);

void clearScreen(void);

//void displayExplicitBoard(void);

void displayBoard(char[ROWS][COLS]);

void displayDice(char[DICE][SIDES]);

char getLetter(char[DICE][SIDES], int);

void createBoard(char dice[DICE][SIDES], char board[ROWS][COLS], int usedDie[DICE]);

void playGame(struct Player *chris, char board[ROWS][COLS]);

void displayWordsFound(struct Player *chris);

void scoreWords(struct Player *chris);

int getWordLength(const char word[LENGTH]);


int main() {
    int die = 0;
    char dice[DICE][SIDES] = {
            {'D', 'R', 'L', 'X', 'E', 'I'},
            {'C', 'P', 'O', 'H', 'S', 'A'},
            {'N', 'H', 'N', 'L', 'Z', 'R'},
            {'W', 'T', 'O', 'O', 'T', 'A'},
            {'I', 'O', 'S', 'S', 'E', 'T'},
            {'N', 'W', 'E', 'G', 'H', 'E'},
            {'B', 'O', 'O', 'J', 'A', 'B'},
            {'U', 'I', 'E', 'N', 'E', 'S'},
            {'P', 'S', 'A', 'F', 'K', 'F'},
            {'I', 'U', 'N', 'H', 'M', 'Q'},
            {'Y', 'R', 'D', 'V', 'E', 'L'},
            {'V', 'E', 'H', 'W', 'H', 'R'},
            {'I', 'O', 'T', 'M', 'U', 'C'},
            {'T', 'Y', 'E', 'T', 'T', 'R'},
            {'S', 'T', 'I', 'T', 'Y', 'D'},
            {'A', 'G', 'A', 'E', 'E', 'N'}
    };

    char board[ROWS][COLS];

    int usedDie[DICE];

    struct Player christopher;

    memset(usedDie, 0, sizeof usedDie);

    memset(board, SPACE, sizeof board);

    srand(time(0));


    welcomeScreen();
    clearScreen();
    //  displayDice(dice);
    // clearScreen();
    getLetter(dice, die);
    createBoard(dice, board, usedDie);
    playGame(&christopher, board);
    //  displayBoard(board);
    return 0;
}


// definition of functions
void welcomeScreen(void) {
    char letter_1 = 'B';
    char letter_2 = 'O';
    char letter_3 = 'G';
    char letter_4 = 'L';
    char letter_5 = 'E';
    // first line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%5c%c%c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%5c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%5c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%5c%c", letter_4, letter_4);
    printf("%7c%c%c%c%c%c", letter_5, letter_5, letter_5, letter_5, letter_5, letter_5);

    printf("\n");

    // second line of presentation
    printf("%20c%c  %c%c", letter_1, letter_1, letter_1, letter_1);
    printf("%3c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c", letter_3, letter_3);
    printf("%8c%c", letter_3, letter_3);
    printf("%9c%c", letter_4, letter_4);
    printf("%7c%c", letter_5, letter_5);


    printf("\n");


    // third line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%4c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c", letter_3, letter_3);
    printf("%8c%c", letter_3, letter_3);
    printf("%9c%c", letter_4, letter_4);
    printf("%7c%c%c%c", letter_5, letter_5, letter_5, letter_5);

    printf("\n");

    // fourth line of presentation
    printf("%20c%c  %c%c", letter_1, letter_1, letter_1, letter_1);
    printf("%3c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c  %c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%3c%c  %c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c", letter_4, letter_4);
    printf("%7c%c", letter_5, letter_5);

    printf("\n");

    // fifth line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%5c%c%c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%5c%c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c%c%c%c%c", letter_4, letter_4, letter_4, letter_4, letter_4, letter_4);
    printf("%3c%c%c%c%c%c", letter_5, letter_5, letter_5, letter_5, letter_5, letter_5);


    printf("\n");

    //rules presentation
    char space = ' ';
    printf("RULES OF THE GAME:\n");
    printf("%8c1. The player is presented with a Boggle board.\n", space);
    printf("%8c2. The player will have three minutes to find as many words as possible.\n", space);
    printf("%8c3. Words must contain three letters or more.\n", space);
    printf("%8c4. Words are formed from adjoining letters.\n", space);
    printf("%8c5. Letters must join in the proper sequence to spell a word.\n", space);
    printf("%8c6. Letters may join horizontally, vertically, or diagonally, to the left, right, up or down.\n", space);
    printf("%8c7. No letter cube may be used more than once in a single word.\n", space);
    printf("%8c8. Words submitted will be scored accordingly.\n", space);
    printf("%8c9. Good Luck!\n", space);

}

void clearScreen(void) {
    printf("\n");
    char userInput;
    printf("%30c Hit <Enter> to continue!", ' ');
    scanf("%c", &userInput);
    system("cls");
    //system("clear");
}

/*void displayExplicitBoard(void) {
    printf("\n");
    printf("|-----------------------|\n");
    printf("|     Boggle Board      |\n");
    printf("|-----------------------|\n");
    printf("|  T  |  A  |  O  |  C  |\n");
    printf("|-----------------------|\n");
    printf("|  L  |  I  |  S  |  M  |\n");
    printf("|-----------------------|\n");
    printf("|  U  |  N  |  B  |  I  |\n");
    printf("|-----------------------|\n");
    printf("|  B  |  O  |  G  |  D  |\n");
    printf("|-----------------------|\n");
}*/

void displayHeader() {
    printf("\n|");
    for (int p = 0; p < ROWS; p++) {
        printf("------");
    }
    printf("|\n");
}

void displayBoard(char board[ROWS][COLS]) {
    char name[] = "Boggle Board";
    int size = sizeof name;
    int numberOfWhiteSpace = 6 * ROWS;
    int diff = numberOfWhiteSpace - size;
    int divisionOfSpace = diff / 2;
    displayHeader();
    printf("|");
    for (int i = 0; i < divisionOfSpace; i++) {
        printf(" ");
    }
    printf("%s", name);
    for (int i = 0; i < divisionOfSpace; i++) {
        printf(" ");
    }
    printf("  |");
    displayHeader();
    for (int row = 0; row < ROWS; row++) {
        // generateCharacters(characters);
        for (int col = 0; col < COLS; col++) {
            printf("|  %c  ", board[row][col]);
        }
        printf(" |");
        displayHeader();
    }
}

void displayDice(char dice[DICE][SIDES]) {
    int row;
    int col;

    printf("BOGGLE DICE\n\n");
    for (row = 0; row < DICE; row++) {
        printf("Die %d\n", (row + 1));
        for (col = 0; col < SIDES; col++) {
            printf("%2c", dice[row][col]);
        }
        printf("\n");
    }
}

char getLetter(char dice[DICE][SIDES], int row) {
    char letter;
    int col;

    col = rand() % (SIDES);
    letter = dice[row][col];

    return letter;
}

void createBoard(char dice[DICE][SIDES], char board[ROWS][COLS], int usedDie[DICE]) {
    char letter;
    int row;
    int col;
    int die;

    for (row = 0; row < ROWS; row++) {
        col = 0;
        while (col < COLS) {
            die = rand() % DICE;
            if (die != usedDie[DICE]) {
                letter = getLetter(dice, die);
                board[row][col] = letter;
                usedDie[die] = TRUE;
                col++;
            }
        }
    }
}

void playGame(struct Player *chris, char board[ROWS][COLS]) {
    int play = TRUE;  // control game play
    int idx = 0; // reference the structure
    long seconds = 0;
    long milliseconds;
    long timeLeft;
    long countDownTimeSecs = TIME;
    clock_t startTime;
    clock_t countTime;

    printf("\nPlayer, please enter your name");
    fgets(chris->name, NAME, stdin);
    // removing new line character from the name after using fgets
    chris->name[strcspn(chris->name, "\n")] = 0;
    chris->count = 0;
    chris->score = 0;

    printf("\n%s let's play Boggle\n", chris->name);

    startTime = clock();
    timeLeft = countDownTimeSecs - seconds;
    displayBoard(board);

    while (timeLeft > 0) {
        countTime = clock();
        milliseconds = (countTime - startTime); // 1 sec has 10000 ticks whereas 1 sec has 1000 ms
        seconds = milliseconds / CLOCKS_PER_SEC;
        timeLeft = countDownTimeSecs - seconds;
        printf("\nType the word found and the <Enter> key:");
        fgets(chris->words[idx], LENGTH, stdin);
        chris->words[idx][strcspn(chris->words[idx], "\n")] = 0;
        chris->count++;
        idx++;

    }
    clearScreen();
    printf("Time is up!\n");
    displayWordsFound(chris);
    scoreWords(chris)
}

void displayWordsFound(struct Player *chris) {
    int w;
    printf("Words found %d:\n", chris->count);
    for (w = 0; w < chris->count; w++) {
        printf("%s\n", chris->words[w]);
    }
    printf("\n");
}

int getWordLength(const char word[LENGTH]) {
    int count = 0;
    int idx = 0;

    while (word[idx] != '\0') {
        count++;
        idx++;
    }
    return count;
}

void scoreWords(struct Player *chris) {
    for (int i = 0; i < chris->count; i++) {
        int length = getWordLength(chris->words[i]);
        if (length <= 2) {
            chris->score += 0;
        } else if (length == 3) {
            chris->score += 1;
        } else if (length == 4) {
            chris->score += 1;
        } else if (length == 5) {
            chris->score += 2;
        } else if (length == 6) {
            chris->score += 3;
        } else if (length == 7) {
            chris->score += 4;
        } else if (length <= 17) {
            chris->score += 11;
        }
    }
    printf("%s final score is %d\n", chris->name, chris->score);
}