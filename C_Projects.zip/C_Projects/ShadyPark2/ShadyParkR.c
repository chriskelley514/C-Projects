#include <stdio.h>
#include <math.h>
#include <stdlib.h>

struct tower{
    int location;
    int height;
    double shade;
};

double binarySearch_east(double high, double low, struct tower *tower, double desiredshadedArea, int amountTowers);

int main() {
    int amountTowers;
    int parkSize;
    int percentShade;
    int totalHeight;
    double toRadian = (M_PI / 180);
    double mid; 
    double degreeToRadian;
    double desiredShadedArea;
    
    double radianToDegree = (180 / M_PI);
    double high = 90;
    double low = 0;
    double totalShade;
    double parkArea;   
    
    struct tower * tower;

    scanf("%d %d %d", &amountTowers, &parkSize, &percentShade);

    tower = (struct tower*)malloc(amountTowers * sizeof(*tower));

    for(int i = 0; i < amountTowers; i++){
        scanf("%d %d", &tower[i].location, &tower[i].height);
    }
    
    int maxTower = tower[0].height; 
    
    for (int i = 1; i < amountTowers; i++){
    	if(tower[i].height > maxTower){
    		maxTower = tower[i].height;
    	}
    }
     
    parkArea = parkSize * maxTower; 

    double desiredshadedArea = (parkArea * percentShade) / 100;
    
    //while(!desiredShadedArea){
    mid = binarySearch_east(high, low, tower, desiredshadedArea, amountTowers);
    //}
    
    printf("%lf", mid); 

    free(tower);

    return 0;
}

double binarySearch_east(double high, double low, struct tower *tower, double desiredshadedArea, int amountTowers){
    double degreeToRadian;
    double mid;
    high = 90;
    low = 0;
    //high = *high * *degreeToRadian;
    //low = *low * *degreeToRadian; 
    double areaTriangle; 
    
    //double sunArea;
    
    //double longestShade; 
    double positionShade[amountTowers]; 
    
    while(low <= high){
    
    mid = (low + high) / 2;

    for(int i = 0; i < amountTowers; i++) {
        tower[i].shade = tower[i].height * tan(mid);
        //totalShade += tower[i].shade;
        positionShade[i] = tower[i].location - tower[i].shade;

        if (positionShade[i] > positionShade[i++]) {
            positionShade[i] = tower[i++].location - tower[i++].shade;
        }

        areaTriangle = (1 / 2) * (tower[i].height / tower[i].shade);
    }
        
        //sunArea = tower[i++].location - positionShade;
         
        /*if(positionShade > tower[i++].location){
            tower[i++].shade;
            continue;
        }
        else{
            tower[i].shade;
        }*/
    } 
    /*printf("%lf\n", mid);
    printf("%lf\n", areaTriangle);
    printf("%lf\n", desiredshadedArea);
    return 0;*/

    if (areaTriangle == desiredshadedArea){
        return mid;
    }

    else if (areaTriangle > desiredshadedArea){
        low = mid;
        return low;
        }
        
    else{ 
    	high = mid;
    	return high;
    	} 
    }
    return -1;

