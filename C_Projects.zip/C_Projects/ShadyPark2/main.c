#include <stdio.h>
#include <math.h>
#include <stdlib.h>

struct tower{
    int location;
    int height;
    double shade;
};

int main() {
    int amountTowers;
    int parkSize;
    int percentShade;
    struct tower * tower;

    scanf("%d %d %d", &amountTowers, &parkSize, &percentShade);

    tower = (struct tower*)malloc(amountTowers * sizeof(*tower));

    for(int i = 0; i < amountTowers; i++){
        scanf("%d %d", &tower[i].location, &tower[i].height);
    }


    double shadedArea = (parkSize * percentShade) / 100;

    return 0;
}

double binarySearch_east(double high, double low, struct tower *tower, double shadedArea, int amountTowers){
    double mid = (low + high) / 2;
    double degreeToRadian = (90 - mid) * (M_PI / 180);
    double totalShade;

    for(int i = 0; i < amountTowers; i++){
        tower[i].shade = tower[i].height * tan(degreeToRadian);
        if(1){
            totalshadowLength += towerShadow[i];
            continue;
        }
        else{
            totalshadowLength += towerShadow[sunBlockingTowers];
        }
        totalShade += tower[i].shade;
    }

    if (totalshadowLength == shadedArea){
        return totalshadowLength;
    }

    else if (totalshadowLength > shadedArea){
        return binarySearch_east(location, height, high, mid, shadedArea, totalshadowLength, towerShadow, sunBlockingTowers);
    }

    else if (totalshadowLength < shadedArea){
        return binarySearch_east(location, height, mid, low, shadedArea, totalshadowLength, towerShadow, sunBlockingTowers);
    }
}

