#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <synchapi.h>
#include <stdbool.h>

#define ROWS 4
#define COLS 4
#define LETTERS 26

// declaration of functions
void welcomeScreen(void);

void clearScreen(void);

void displayExplicitBoard(void);

void displayBoard(void);

//char randomNumberGenerator(void);

//void generateCharacters(char characters[COLS]);


int main() {
    welcomeScreen();
    clearScreen();
    displayExplicitBoard();
    clearScreen();
    displayBoard();
    return 0;
}


// definition of functions
void welcomeScreen(void) {
    char letter_1 = 'B';
    char letter_2 = 'O';
    char letter_3 = 'G';
    char letter_4 = 'L';
    char letter_5 = 'E';
    // first line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%5c%c%c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%5c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%5c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%5c%c", letter_4, letter_4);
    printf("%7c%c%c%c%c%c", letter_5, letter_5, letter_5, letter_5, letter_5, letter_5);

    printf("\n");

    // second line of presentation
    printf("%20c%c  %c%c", letter_1, letter_1, letter_1, letter_1);
    printf("%3c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c", letter_3, letter_3);
    printf("%8c%c", letter_3, letter_3);
    printf("%9c%c", letter_4, letter_4);
    printf("%7c%c", letter_5, letter_5);


    printf("\n");


    // third line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%4c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c", letter_3, letter_3);
    printf("%8c%c", letter_3, letter_3);
    printf("%9c%c", letter_4, letter_4);
    printf("%7c%c%c%c", letter_5, letter_5, letter_5, letter_5);

    printf("\n");

    // fourth line of presentation
    printf("%20c%c  %c%c", letter_1, letter_1, letter_1, letter_1);
    printf("%3c%c  %c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%3c%c  %c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%3c%c  %c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c", letter_4, letter_4);
    printf("%7c%c", letter_5, letter_5);

    printf("\n");

    // fifth line of presentation
    printf("%20c%c%c%c%c", letter_1, letter_1, letter_1, letter_1, letter_1);
    printf("%5c%c%c%c", letter_2, letter_2, letter_2, letter_2);
    printf("%5c%c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c%c%c%c%c", letter_3, letter_3, letter_3, letter_3, letter_3, letter_3);
    printf("%4c%c%c%c%c%c", letter_4, letter_4, letter_4, letter_4, letter_4, letter_4);
    printf("%3c%c%c%c%c%c", letter_5, letter_5, letter_5, letter_5, letter_5, letter_5);


    printf("\n");

    //rules presentation
    char space = ' ';
    printf("RULES OF THE GAME:\n");
    printf("%8c1. The player is presented with a Boggle board.\n", space);
    printf("%8c2. The player will have three minutes to find as many words as possible.\n", space);
    printf("%8c3. Words must contain three letters or more.\n", space);
    printf("%8c4. Words are formed from adjoining letters.\n", space);
    printf("%8c5. Letters must join in the proper sequence to spell a word.\n", space);
    printf("%8c6. Letters may join horizontally, vertically, or diagonally, to the left, right, up or down.\n", space);
    printf("%8c7. No letter cube may be used more than once in a single word.\n", space);
    printf("%8c8. Words submitted will be scored accordingly.\n", space);
    printf("%8c9. Good Luck!\n", space);

}

void clearScreen(void) {
    printf("\n");
    char userInput;
    printf("%30c Hit <Enter> to continue!", ' ');
    scanf("%c", &userInput);
    system("cls");
    //system("clear");
}

void displayExplicitBoard(void) {
    printf("\n");
    printf("|-----------------------|\n");
    printf("|     Boggle Board      |\n");
    printf("|-----------------------|\n");
    printf("|  T  |  A  |  O  |  C  |\n");
    printf("|-----------------------|\n");
    printf("|  L  |  I  |  S  |  M  |\n");
    printf("|-----------------------|\n");
    printf("|  U  |  N  |  B  |  I  |\n");
    printf("|-----------------------|\n");
    printf("|  B  |  O  |  G  |  D  |\n");
    printf("|-----------------------|\n");
}

void displayHeader(){
    printf("\n|");
    for(int p = 0; p < ROWS; p++){
        printf("------");
    }
    printf("|\n");
}

void displayBoard(void) {
   // char characters[COLS];
   int row;
   int col;
   int num;
   int letter = 'A';
   char name[] = "Boggle Board";
   int size = sizeof name;
   int numberOfWhiteSpace = 6 * ROWS;
   int diff = numberOfWhiteSpace - size;
   int divisionOfSpace = diff / 2;
   displayHeader();
   printf("|");
    for(int i = 0; i < divisionOfSpace; i++){
        printf(" ");
    }
    printf("%s", name);
    for(int i = 0; i < divisionOfSpace; i++){
        printf(" ");
    }
    printf("  |");
    displayHeader();
    for (row = 0; row < ROWS; row++) {
       // generateCharacters(characters);
        for (col = 0; col < COLS; col++) {
            while(true){
                srand(time(NULL)); // seed has to change
                Sleep(1000); // 10
                num = rand() % (LETTERS + 1) + letter;
                if(num >= 65 && num <= 90){
                    printf("|  %c  ", num);
                    break;
                }
            }
        }
        printf(" |");
        displayHeader();
    }
}
