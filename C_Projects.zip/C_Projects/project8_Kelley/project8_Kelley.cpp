#include <iostream>
#include <unordered_map>
#include <string>
#include <functional>

// Structure for Circle
struct Circle {
    double radius;
    Circle() : radius(0) {} // Default constructor
    explicit Circle(double r) : radius(r) {}
};

// Custom hash function
struct MyHasher {
    std::size_t operator()(const std::string& key) const {
        std::size_t hash = 0;
        for (char c : key) {
            hash = hash * 31 + c; // Example hash function: sum of ASCII values
        }
        return hash % 10; // Limiting the hash to 10 elements
    }
};

// Function to display an element
void DisplayElement(const std::unordered_map<std::string, Circle, MyHasher>& hashTable, const std::string& key) {
    auto it = hashTable.find(key);
    if (it != hashTable.end()) {
        std::cout << "Circle with radius: " << it->second.radius << std::endl;
    } else {
        std::cout << "Element not found." << std::endl;
    }
}

int main() {
    std::unordered_map<std::string, Circle, MyHasher> hashTable;
    int choice;
    std::string key;
    double radius;

    do {
        std::cout << "Menu:\n";
        std::cout << "1. Insert an element\n";
        std::cout << "2. Display an element\n";
        std::cout << "3. Erase a single element\n";
        std::cout << "4. Delete all elements\n";
        std::cout << "5. Terminate application\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter the key (string of lowercase letters): ";
                std::cin >> key;
                std::cout << "Enter the radius of the circle: ";
                std::cin >> radius;
                hashTable[key] = Circle(radius);
                std::cout << "Element inserted." << std::endl;
                break;
            case 2:
                std::cout << "Enter the key to display: ";
                std::cin >> key;
                DisplayElement(hashTable, key);
                break;
            case 3:
                std::cout << "Enter the key to erase: ";
                std::cin >> key;
                if (hashTable.erase(key)) {
                    std::cout << "Element erased." << std::endl;
                } else {
                    std::cout << "Element not found." << std::endl;
                }
                break;
            case 4:
                hashTable.clear();
                std::cout << "All elements deleted." << std::endl;
                break;
            case 5:
                std::cout << "Terminating application." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 5);

    return 0;
}
