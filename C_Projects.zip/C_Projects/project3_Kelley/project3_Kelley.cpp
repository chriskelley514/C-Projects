#include <iostream>
#include "matrix.h"

int main() {
    // Initialize A and B matrices
    matrix<double> A = {
            {0, 0},
            {0, 0},
            {0, 0}
    };

    matrix<double> B = {
            {0, 0},
            {0, 0},
            {0, 0}
    };
    // Prompt, input, store values for matrix A
    std::cout << "Enter values for matrix A:" << std::endl;
    for (int i = 0; i < A.numrows(); i++) {
        for (int j = 0; j < A.numcols(); j++) {
            std::cout << "A[" << i << "][" << j << "]:";
            std::cin >> A[i][j];
        }
    }
    // Prompt, input, store values for matrix B
    std::cout << "Enter values for matrix B:" << std::endl;
    for (int i = 0; i < B.numrows(); i++) {
        for (int j = 0; j < B.numcols(); j++) {
            std::cout << "B[" << i << "][" << j << "]:";
            std::cin >> B[i][j];
        }
    }

    // Perform matrix addition: C = A + B
    matrix<double> C(A.numrows(), A.numcols());
    for (int i = 0; i < C.numrows(); i++) {
        for (int j = 0; j < C.numcols(); j++) {
            C[i][j] = A[i][j] + B[i][j];
        }
    }

    // Display values from matrix C
    std::cout << "Result matrix C = A + B:" << std::endl;
    for (int i = 0; i < C.numrows(); i++) {
        for (int j = 0; j < C.numcols(); j++) {
            std::cout << C[i][j] << "  ";
        }
        std::cout << std::endl;
    }

    return 0;
}
