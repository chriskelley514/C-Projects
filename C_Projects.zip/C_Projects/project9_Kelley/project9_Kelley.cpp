#include <iostream>
#include <string>
#include <vector>
#include <cmath>

// Circle class (assuming a simple implementation for demonstration)
class Circle {
public:
    double radius;
    Circle(double r) : radius(r) {}

    // Method to display the circle's radius
    void display() const {
        std::cout << "Circle with radius: " << radius << std::endl;
    }
};

// Node struct to hold key and Circle object
struct Node {
    std::string key; // The key for the hash table
    Circle* circle;  // Pointer to a Circle object
    bool isOccupied; // Flag to check if the node is occupied

    Node() : circle(nullptr), isOccupied(false) {}
};

// Hash table class
class HashTable {
public:
    // Constructor to initialize hash table with given size
    HashTable(int size) : size(size), count(0) {
        table = new Node[size];
    }

    // Destructor to deallocate memory
    ~HashTable() {
        for (int i = 0; i < size; ++i) {
            if (table[i].isOccupied) {
                delete table[i].circle;
            }
        }
        delete[] table;
    }

    // Function to insert an element into the hash table
    bool insertElement(const std::string& key, Circle* circle) {
        if (count >= size) {
            std::cerr << "Error: Hash table is full." << std::endl;
            return false;
        }

        int index = myHasher(key);
        int startIndex = index;
        while (table[index].isOccupied) {
            index = (index + 1) % size;
            if (index == startIndex) {
                std::cerr << "Error: Hash table is full." << std::endl;
                return false;
            }
        }

        table[index].key = key;
        table[index].circle = circle;
        table[index].isOccupied = true;
        ++count;
        return true;
    }

    // Function to display an element from the hash table by key
    Circle* displayElement(const std::string& key) const {
        int index = myHasher(key);
        int startIndex = index;
        while (table[index].isOccupied) {
            if (table[index].key == key) {
                return table[index].circle;
            }
            index = (index + 1) % size;
            if (index == startIndex) {
                break;
            }
        }
        return nullptr;
    }

    // Function to display the menu for user interaction
    void displayMenu() {
        int choice;
        do {
            std::cout << "1. Resize hash table" << std::endl;
            std::cout << "2. Insert element" << std::endl;
            std::cout << "3. Display element" << std::endl;
            std::cout << "4. Terminate application" << std::endl;
            std::cout << "Enter your choice: ";
            std::cin >> choice;

            switch (choice) {
                case 1:
                    resizeTable();
                    break;
                case 2: {
                    std::string key;
                    double radius;
                    std::cout << "Enter key: ";
                    std::cin >> key;
                    std::cout << "Enter circle radius: ";
                    std::cin >> radius;
                    if (!insertElement(key, new Circle(radius))) {
                        std::cerr << "Failed to insert element." << std::endl;
                    }
                    break;
                }
                case 3: {
                    std::string key;
                    std::cout << "Enter key: ";
                    std::cin >> key;
                    Circle* circle = displayElement(key);
                    if (circle) {
                        circle->display();
                    } else {
                        std::cerr << "Element not found." << std::endl;
                    }
                    break;
                }
                case 4:
                    std::cout << "Terminating application." << std::endl;
                    break;
                default:
                    std::cerr << "Invalid choice." << std::endl;
            }
        } while (choice != 4);
    }

private:
    Node* table;  // Array of nodes for the hash table
    int size;     // Size of the hash table
    int count;    // Current number of elements in the hash table

    // Hash function to compute the index based on the key
    int myHasher(const std::string& key) const {
        int sum = 0;
        for (char ch : key) {
            sum += static_cast<int>(ch);
        }
        return sum % size;
    }

    // Function to find the next prime number greater than a given number
    int getNextPrime(int n) const {
        while (!isPrime(n)) {
            ++n;
        }
        return n;
    }

    // Function to check if a number is prime
    bool isPrime(int n) const {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }

    // Function to resize the hash table
    void resizeTable() {
        int numElements;
        std::cout << "Enter number of elements to insert: ";
        std::cin >> numElements;
        int newSize = getNextPrime(2 * numElements);

        delete[] table; // Deallocate old table memory
        table = new Node[newSize]; // Allocate new table
        size = newSize;
        count = 0;

        std::cout << "Hash table resized to " << size << " elements." << std::endl;
    }
};

int main() {
    HashTable hashTable(11); // Initial size of 11
    hashTable.displayMenu();

    return 0;
}
