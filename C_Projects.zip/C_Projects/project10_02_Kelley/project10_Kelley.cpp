#include <iostream>
#include <vector>

// Class representing a node in the graph
class GraphNode {
public:
    int pointNum; // Node identifier
    std::vector<GraphNode*> connectedNodes; // List of nodes this node is connected to

    // Constructor to initialize the node with a given number
    explicit GraphNode(int num) : pointNum(num) {}

    // Method to ass a connection to another node
    void addConnection(GraphNode* node) {
        connectedNodes.push_back(node);
    }
};

// Class representing the graph
class Graph {
private:
    std::vector<GraphNode*> nodes; // List of nodes in the graph

public:
    // Destructor to clean up the nodes
    ~Graph() {
        for (auto node : nodes) {
            delete node;
        }
    }
    // Method to create nodes in a graph
    void createNodes(int n) {
        for (int i = 1; i <= n; ++i) {
            nodes.push_back(new GraphNode(i));
        }
    }
    // Method to add connections between nodes based on the adjacency matrix
    void addConnections(const std::vector<std::vector<int>>& adjacencyMatrix) {
        for (int i = 0; i < adjacencyMatrix.size(); ++i) {
            for (int j = 0; j < adjacencyMatrix[i].size(); ++j) {
                if (adjacencyMatrix[i][j] == 1) {
                    nodes[i]->addConnection(nodes[j]);
                }
            }
        }
    }
    // Method to build the graph with the given number of nodes and adjacency matrix
    void buildGraph(int n, const std::vector<std::vector<int>>& adjacencyMatrix) {
        createNodes(n);
        addConnections(adjacencyMatrix);
    }
    // Method to display the graph's connections
    void displayGraph() {
        for (auto node : nodes) {
            std::cout << "Node " << node->pointNum << " connects to: ";
            for (auto connectedNode : node->connectedNodes) {
                std::cout << connectedNode->pointNum << " ";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    int n;
    std::cout << "Enter the number of nodes: ";
    std::cin >> n;

    // Create an adjacency matrix based on user input
    std::vector<std::vector<int>> adjacencyMatrix(n, std::vector<int>(n));

    std::cout << "Enter the adjacency matrix with a space between connections(0 or 1):\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            std::cin >> adjacencyMatrix[i][j];
        }
    }

    // Create a graph and build it using the providing adjacency matrix
    Graph graph;
    graph.buildGraph(n, adjacencyMatrix);
    std::cout << "\n";
    std::cout << "Graph connections:\n";
   // Display the graph's connections
    graph.displayGraph();

    return 0;
}
