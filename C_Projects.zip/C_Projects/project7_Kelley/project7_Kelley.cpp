#include <iostream>
#include <queue>
#include <vector>

// Circle class definition
class Circle {
public:
    double radius;  // Stores the radius of the circle

    // Constructor that initializes a circle with a given radius
    Circle(double r) : radius(r) {}

    // Method to display the circle's radius
    void display() const {
        std::cout << "Circle with radius: " << radius << std::endl;
    }
};

// Function to display the menu and interact with the queue of circles
void menu() {
    std::queue<Circle> circleQueue;  // Queue for storing circles in insertion order
    std::vector<Circle> displayHelper; // Vector to facilitate displaying circles by index

    int choice;  // Variable to store the user's choice in the menu
    double radius;  // Variable to store the radius of the circle to be added
    int index;  // Variable to store the index of the circle to be displayed

    while (true) {
        // Display menu options to the user
        std::cout << "\nMenu:\n"
                  << "1. Insert Circle into Queue\n"
                  << "2. Display a Circle by Index\n"
                  << "3. Remove all Circles\n"
                  << "4. Exit\n"
                  << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {  // Case for inserting a new circle
                std::cout << "Enter radius of the circle: ";
                std::cin >> radius;
                Circle newCircle(radius);  // Create a new Circle instance
                circleQueue.push(newCircle); // Enqueue the new circle
                displayHelper.push_back(newCircle); // Also store it in the vector for index-based display
                std::cout << "Circle added to the queue." << std::endl;
                break;
            }
            case 2:  // Case for displaying a circle by its index
                if (!displayHelper.empty()) {
                    std::cout << "Enter index of the circle to display (1-based index): ";
                    std::cin >> index;
                    // Check if the index is within the valid range
                    if (index > 0 && index <= displayHelper.size()) {
                        displayHelper[index - 1].display();  // Display the circle at the given index
                    } else {
                        std::cout << "Index out of range." << std::endl;  // Handle out of range index
                    }
                } else {
                    std::cout << "The queue is empty." << std::endl;  // Handle the case when the queue is empty
                }
                break;
            case 3:  // Case for removing all circles from the queue
                while (!circleQueue.empty()) {
                    circleQueue.pop();  // Remove each circle from the queue
                }
                displayHelper.clear();  // Also clear the vector
                std::cout << "All circles removed from the queue." << std::endl;
                break;
            case 4:  // Case for exiting the program
                return;
            default:  // Default case for invalid choices
                std::cout << "Invalid choice, please try again!" << std::endl;
        }
    }
}

int main() {
    menu();  // Execute the menu function
    return 0;
}
