#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>
#include <stdbool.h>

 struct Boat {
    int start_x;
    int start_y;
    char direction;
    char name[20 + 1];
};
 struct Storm {
    int corner1_x, corner1_y, corner2_x, corner2_y, corner3_x, corner3_y, corner4_x, corner4_y;
    int storm_x, storm_w, storm_endx;
    int storm_y, storm_h, storm_endy;
    int boatsStorm;
    int storm_x_delta, storm_y_delta;
};
 struct ArrayList_Boat {
    struct Boat *boat_to_boat; // array of boats dynamically allocated
    int size, cap;
    int currentIndex;
};
 struct ArrayList_Storm {
    struct Storm *storm_to_storm;
    int size, cap;
    int currentIndex;
};

bool ArrayList_add_boat(struct ArrayList_Boat *list, struct Boat *element) {
    // the empty boat or dynamic list is not allocated
    if (element == NULL || list->boat_to_boat == NULL) {
        return false;
    }
    // current index has become equal to capacity
    if (list->currentIndex >= list->cap) {
        list->boat_to_boat = realloc(list->boat_to_boat, sizeof(struct Boat) * 2 * list->cap); // doubling the capacity
        list->cap = 2 * list->cap;
    }

    // adding values to the list
    list->boat_to_boat[list->currentIndex] = *element; // allocating the boat to the array
    list->currentIndex++; // increasing the index of the array
    list->size++; // updating the number of boats in the array

    return true;
}

bool ArrayList_add_Storm(struct ArrayList_Storm *list, struct Storm *element) {
    // the empty boat or dynamic list is not allocated
    if (element == NULL || list->storm_to_storm == NULL) {
        return false;
    }
    // current index has become equal to capacity
    if (list->currentIndex >= list->cap) {
        list->storm_to_storm = realloc(list->storm_to_storm,
                                       sizeof(struct Storm) * 2 * list->cap); // doubling the capacity
        list->cap = 2 * list->cap;
    }
    // adding values to the list
    list->storm_to_storm[list->currentIndex] = *element; // allocating the boat to the array
    list->currentIndex++; // increasing the index of the array
    list->size++; // updating the number of boats in the array

    return true;
}

bool is_inside(int x, int y, int n, int X[], int Y[]) {
    int i, j, c = 0;
    for (i = 0, j = n - 1; i < n; j = i++) {
        if ((((Y[i] <= y) && (y < Y[j])) ||
             ((Y[j] <= y) && (y < Y[i]))) &&
            (x < (X[j] - X[i]) * (y - Y[i]) / (Y[j] - Y[i]) + X[i]))
            c = !c;
    }
    return c;
}


int main() {
    int world_x; //WW
    int world_y; //WH
    int userChoice = 0; //1, 2, 3, 4
    int index = 0;
    struct ArrayList_Boat list_boat;
    struct ArrayList_Storm list_storm;
    struct Boat boat;
    struct Storm storm;
    int t;
    char *info_ptr;

    scanf("%d %d", &world_x, &world_y);

    // validate world x and y
    if (world_x < 20 || world_x > 500000 || world_y < 20 || world_y > 500000) {
        exit(1);
    }

    // dynamic allocation to list_boat and list_storm
    list_boat.boat_to_boat = calloc(10, sizeof(struct Boat));
    list_boat.currentIndex = 0;
    list_boat.size = 0;
    list_boat.cap = 10;

    list_storm.storm_to_storm = calloc(10, sizeof(struct Storm));
    list_storm.currentIndex = 0;
    list_storm.size = 0;
    list_storm.cap = 10;

    int cur_time = (int) time(NULL);
    int min = cur_time / 60;

    while (true) {
        char UserInput[100 + 1];
        fgets(UserInput, 101, stdin);
        //UserChoice
        info_ptr = strtok(UserInput, " ");
        userChoice = atoi(info_ptr);
        struct Boat *tempBoat = NULL;
        tempBoat = calloc(1, sizeof(struct Boat));
        struct Storm *tempStorm = NULL;
        tempStorm = calloc(1, sizeof(struct Storm));
        int limit;
        int counter;


        switch (userChoice) {
            //Ships
            case (1):
                // creating a temp boat
                //X
                info_ptr = strtok(NULL, " ");
                // boat1.start_x = atoi(info_ptr) + 1;
                tempBoat->start_x = atoi(info_ptr) + 1;
                //Y
                info_ptr = strtok(NULL, " ");
                //boat1.start_y = atoi(info_ptr) + 1;
                tempBoat->start_y = atoi(info_ptr) + 1;
                //Direction
                info_ptr = strtok(NULL, " ");
                //boat1.direction[index] = (char) *info_ptr;
                tempBoat->direction = (char) *info_ptr;
                //Name
                info_ptr = strtok(NULL, " ");
                index = 0;
                while (strcmp(info_ptr, "\n")) {
                    //boat1.name[index] = (char) *info_ptr;
                    tempBoat->name[index] = (char) *info_ptr;
                    index++;
                    info_ptr++;
                }

                // adding boat to the list
                ArrayList_add_boat(&list_boat, tempBoat);
                break;
                //time
            case (2):
                info_ptr = strtok(NULL, " ");
                t = atoi(info_ptr);
                min = (int) (min + t);
                tempBoat = calloc(1, sizeof(struct Boat));
                for (int i = 0; i < list_boat.size; i++) {
                    tempBoat = &(list_boat.boat_to_boat[i]);
                    switch (tempBoat->direction) {
                        case 'R':
                            if(tempBoat->start_x + t <= world_x)
                                tempBoat->start_x += t;
                            else
                                tempBoat->start_x = (int) (tempBoat->start_x + t - world_x);
                            break;
                        case 'L':
                            if(tempBoat->start_x - t >= 1)
                                tempBoat->start_x -= t;
                            else
                                tempBoat->start_x = (int) (world_x + (tempBoat->start_x - t));
                            break;
                        case 'U':
                            if(tempBoat->start_y + t <= world_y)
                                tempBoat->start_y += t;
                            else
                                tempBoat->start_y = (int) (tempBoat->start_y + t - world_y);
                            break;
                        case 'D':
                            if(tempBoat->start_y - t >= 1)
                                tempBoat->start_y -= t;
                            else
                                tempBoat->start_y = (int) (world_y + (tempBoat->start_y - t));
                            break;
                        default:
                            printf("Invalid");
                            break;
                    }
                }
                break;
                //storm
            case (3):
                //storm x
                // creating dynamic array for storing the names of the boats
                limit = 10;
                counter = 0;
                char **tempNames = (char **) calloc(limit, sizeof(char *));
                for (int i = 0; i < limit; i++) {
                    tempNames[i] = calloc(21, sizeof(char));
                }

                info_ptr = strtok(NULL, " ");
                tempStorm->corner1_x  = atoi(info_ptr) + 1;
                //storm1.storm_x -= 1;
                //storm y
                info_ptr = strtok(NULL, " ");
                tempStorm->corner1_y = atoi(info_ptr) + 1;
                //storm1.storm_y -= 1;
                //storm w
                info_ptr = strtok(NULL, " ");
                tempStorm->storm_w = atoi(info_ptr);
                //storm1.storm_x -= 1;
                //storm h
                info_ptr = strtok(NULL, " ");
                tempStorm->storm_h = atoi(info_ptr);

                int tempVal = 0;
                bool edgeTest = false;
                tempVal = tempStorm->corner1_x + tempStorm->storm_w;
                if(tempVal <= world_x + 1){
                    tempStorm->corner2_x = tempVal;
                }else{
                    tempStorm->corner2_x = tempVal - (world_x + 1);
                    edgeTest = true;
                }
                tempStorm->corner2_y = tempStorm->corner1_y;

                tempStorm->corner3_x = tempStorm->corner2_x;
                tempVal = tempStorm->corner2_y + tempStorm->storm_h;
                if(tempVal >= 1 && tempVal <= world_y + 1){
                    tempStorm->corner3_y = tempVal;
                }else{
                    tempStorm->corner3_y = tempVal - world_y - 1;
                    edgeTest = true;
                }

                tempStorm->corner4_x = tempStorm->corner1_x;
                tempStorm->corner4_y = tempStorm->corner3_y;


                tempStorm->storm_endx = (tempStorm->storm_x + tempStorm->storm_w);
                tempStorm->storm_endy = (tempStorm->storm_y + tempStorm->storm_h);

                tempStorm->storm_x_delta = tempStorm->storm_endx - tempStorm->storm_x;
                tempStorm->storm_y_delta = tempStorm->storm_endy - tempStorm->storm_y;


                //loop through all boats and find ones in storm
                for (int i = 0; i < list_boat.size; i++) {
                    tempBoat = &(list_boat.boat_to_boat[i]);
                    int X[] = {tempStorm->corner1_x, tempStorm->corner2_x, tempStorm->corner3_x, tempStorm->corner4_x};
                    int Y[] = {tempStorm->corner1_y, tempStorm->corner2_y, tempStorm->corner3_y, tempStorm->corner4_y};
                    int X_H[] = {1, world_x + 1, world_x + 1, 1};
                    int Y_V[] = {1, world_y + 1, world_y + 1, 1};


                    if (is_inside(tempBoat->start_x, tempBoat->start_y, 4, X, Y)) {
                        if (counter >= limit) {
                            tempNames = realloc(tempNames, sizeof(char) * limit * 2);
                            limit *= 2;
                            for (int j = 0; j < limit; j++) {
                                tempNames[j] = realloc(tempNames[i], sizeof(char) * 21);
                            }
                        }
                        strcpy(tempNames[counter], tempBoat->name);
                        counter++;
                        tempStorm->boatsStorm++;
                    }
                    if(edgeTest){
                        if((is_inside(tempBoat->start_x, tempBoat->start_y, 4, X, Y) == false)  // horizontal edge case
                           && (is_inside(tempBoat->start_x, tempBoat->start_y, 4, X_H, Y) == true)){
                            if (counter >= limit) {
                                tempNames = realloc(tempNames, sizeof(char) * limit * 2);
                                limit *= 2;
                                for (int j = 0; j < limit; j++) {
                                    tempNames[j] = realloc(tempNames[i], sizeof(char) * 21);
                                }
                            }
                            strcpy(tempNames[counter], tempBoat->name);
                            counter++;
                            tempStorm->boatsStorm++;
                        }
                        else if((is_inside(tempBoat->start_x, tempBoat->start_y, 4, X, Y) == false) // verical edge case
                                && (is_inside(tempBoat->start_x, tempBoat->start_y, 4, X, Y_V) == true)){
                            if (counter >= limit) {
                                tempNames = realloc(tempNames, sizeof(char) * limit * 2);
                                limit *= 2;
                                for (int j = 0; j < limit; j++) {
                                    tempNames[j] = realloc(tempNames[i], sizeof(char) * 21);
                                }
                            }
                            strcpy(tempNames[counter], tempBoat->name);
                            counter++;
                            tempStorm->boatsStorm++;
                        }
                    }
                }

                // prints the output if there is any boat
                if (counter != 0) {
                    printf("%d\n", tempStorm->boatsStorm);
                    ArrayList_add_Storm(&list_storm, tempStorm);  // add storm to the list
                    for (int i = 0; i < counter; i++) {
                        printf("%s\n", tempNames[i]);
                    }
                } else {
                    printf("0\n");
                }


                for (int i = 0; i < limit; i++) {
                    free(tempNames[i]);
                }
                free(tempNames);
                break;

            case (4):
                // free the memory
                free(tempBoat);
                free(tempStorm);
                exit(0);
        }
    }
}