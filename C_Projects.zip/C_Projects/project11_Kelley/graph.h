#ifndef GRAPHCLASS_H
#define GRAPHCLASS_H

#include "graphNode.h"
#include <vector>
#include <stack>
#include <iostream>

class Graph {
private:
    int numNodes;
    std::vector<GraphNode> nodes;
    std::vector<std::vector<int>> adjMatrix;
    std::vector<bool> visited;
    std::stack<int> topOrder;

    void dfs(int v) {
        visited[v] = true;

        for (int i = 0; i < numNodes; ++i) {
            if (adjMatrix[v][i] != 0 && !visited[i]) {
                dfs(i);
            }
        }

        topOrder.push(v);
    }

public:
    Graph(int n, int** adjacencyMatrix) : numNodes(n), visited(n, false) {
        for (int i = 0; i < n; ++i) {
            nodes.emplace_back(i);
        }

        adjMatrix.resize(n);
        for (int i = 0; i < n; ++i) {
            adjMatrix[i].resize(n);
            for (int j = 0; j < n; ++j) {
                adjMatrix[i][j] = adjacencyMatrix[i][j];
            }
        }
    }

    void topSort() {
        for (int i = 0; i < numNodes; ++i) {
            if (!visited[i]) {
                dfs(i);
            }
        }

        int counter = 0;
        while (!topOrder.empty()) {
            int v = topOrder.top();
            topOrder.pop();
            nodes[v].setTopNum(++counter);
        }

        // Output the topological order
        for (const auto& node : nodes) {
            std::cout << "Node " << node.value << ": " << node.getTopNum() << std::endl;
        }
    }
};

#endif // GRAPHCLASS_H
